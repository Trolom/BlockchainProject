import json
from web3 import Web3
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class BlockchainService:
    def __init__(self):
        self.web3 = Web3(Web3.HTTPProvider(settings.WEB3_PROVIDER_URI))
        if self.web3.is_connected():
            logger.info("Connected to Ethereum node")
        else:
            logger.error("Failed to connect to Ethereum node")
        self.contract_address = '0x3EcA1114b2Afc77086F48F5Fd2e55376006DF9E2'
        self.contract_abi = self.load_abi()

    def load_abi(self):
        with open('../blockchain/build/contracts/Wallet.json') as f:
            contract_json = json.load(f)
            contract_abi = contract_json['abi']
            return contract_abi

    def get_contract(self):
        return self.web3.eth.contract(address=self.contract_address, abi=self.contract_abi)

    def deposit(self, user_address, currency, amount):
        contract = self.get_contract()
        txn = contract.functions.deposit(currency, amount).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.getTransactionCount(user_address)
        })
        signed_txn = self.web3.eth.account.signTransaction(txn, private_key='USER_PRIVATE_KEY')  # Replace with user private key
        self.web3.eth.sendRawTransaction(signed_txn.rawTransaction)

    def withdraw(self, user_address, currency, amount):
        contract = self.get_contract()
        txn = contract.functions.withdraw(currency, amount).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.getTransactionCount(user_address)
        })
        signed_txn = self.web3.eth.account.signTransaction(txn, private_key='USER_PRIVATE_KEY')  # Replace with user private key
        self.web3.eth.sendRawTransaction(signed_txn.rawTransaction)

    def transfer(self, from_address, to_address, currency, amount):
        contract = self.get_contract()
        txn = contract.functions.transfer(to_address, currency, amount).buildTransaction({
            'from': from_address,
            'nonce': self.web3.eth.getTransactionCount(from_address)
        })
        signed_txn = self.web3.eth.account.signTransaction(txn, private_key='FROM_USER_PRIVATE_KEY')  # Replace with from user private key
        self.web3.eth.sendRawTransaction(signed_txn.rawTransaction)

    def get_balance(self, user_address, currency):
        contract = self.get_contract()
        return contract.functions.getBalance(user_address, currency).call()

    def convert_currency(self, user_address, source_currency, target_currency, amount, conversion_rate):
        contract = self.get_contract()
        txn = contract.functions.convertCurrency(source_currency, target_currency, amount, conversion_rate).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.getTransactionCount(user_address)
        })
        signed_txn = self.web3.eth.account.signTransaction(txn, private_key='USER_PRIVATE_KEY')  # Replace with user private key
        self.web3.eth.sendRawTransaction(signed_txn.rawTransaction)
